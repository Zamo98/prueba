#include "algoritmoGenetico.h"
#include "cargarImagen.h"

int cantidadPoblacion;
int probabilidadMutacion = 2;
int filas,columnas;
int indice;
bool found;
int mat_len;

Vec3b** objetivo;
Vec3b*** genes, ***n_genes;

cargarImagen* obj = nullptr;

int *mat_pool;

void algoritmoGenetico::inicializar(int filas, int columnas) {
    for(int i = 0;  i < filas; i++){
        for(int j = 0; j < columnas; j++){
            genes[::indice][i][j][0] = rand() % 256;
            genes[::indice][i][j][1] = rand() % 256;
            genes[::indice][i][j][2] = rand() % 256;

        }
        ::indice++;
    }
}

void algoritmoGenetico::funcion_Fitness() {
    int contador = 0;
    for(int i = 0; i < filas; i++){
        for(int j = 0; j < columnas; j++){
            if(genes[Indice][i][j][0] == objetivo[i][j][0] || genes[Indice][i][j][1] == objetivo[i][j][1] || genes[Indice][i][j][2] == objetivo[i][j][2]){
                contador++;
            }
        }
    }
    fitness = 1000 * contador / (filas * columnas);
    fitness = (fitness * fitness) / 1000;
}

Mat algoritmoGenetico::colorPixel(Mat image) {
    for(int i = 0; i < image.rows; i++){
        for(int j = 0; j < image.cols; j++){
            image.at<Vec3b>(i,j)[0] = genes[Indice][i][j][0];
            image.at<Vec3b>(i,j)[1] = genes[Indice][i][j][1];
            image.at<Vec3b>(i,j)[2] = genes[Indice][i][j][2];
        }
    }
    return image;
}

void algoritmoGenetico::mutacion() {
    for(int i = 0; i < filas; i++){
        for(int j = 0; j < columnas; j++){
            if(rand() % 100 < probabilidadMutacion){
                n_genes[Indice][i][j][0] = rand() % 256;
                n_genes[Indice][i][j][1] = rand() % 256;
                n_genes[Indice][i][j][2] = rand() % 256;
            }
        }
    }
}

void algoritmoGenetico::cruce(int pos, algoritmoGenetico padre, algoritmoGenetico madre) {
    for(int i = 0; i < filas; i++){
        for(int j = 0; j < columnas; j++) {
            for (int k = 0; k < 3; k++) {
                if((genes[padre.Indice][i][j][k] == objetivo[i][j][k]) || (genes[madre.Indice][i][j][k] == objetivo[i][j][k])){
                    if(rand() % 10 == 0){
                        n_genes[pos][i][j][k] = objetivo[i][j][k];
                    }
                    else{
                        goto branch;
                    }
                }
                else{
                    branch:
                        if(rand() % 2 == 0){
                            n_genes[pos][i][j][k] = genes[padre.Indice][i][j][k];
                        }
                        else{
                            n_genes[pos][i][j][k] = genes[madre.Indice][i][j][k];
                        }
                }
            }
        }
    }
}
algoritmoGenetico* poblacion;

bool aptitud(algoritmoGenetico a, algoritmoGenetico b) {
    return a.fitness > b.fitness;
}

void algoritmoGenetico::principal() {
    srand(time(NULL));
    obj = new cargarImagen();
    cargarImagen i;
    Mat ref;
    Mat best;
    ref = i.image;
    best = ref;
    filas = ref.rows;
    columnas = ref.cols;
    objetivo = new Vec3b * [filas];
    for(int i = 0; i < filas; i++){
        objetivo[i] = new Vec3b[columnas];
    }
    for(int i = 0; i < filas; i++){
        for(int j = 0; j < columnas;j++){
            objetivo[i][j][0] = best.at<Vec3b>(i,j)[0];
            objetivo[i][j][1] = best.at<Vec3b>(i,j)[1];
            objetivo[i][j][2] = best.at<Vec3b>(i,j)[2];
        }
    }
    cantidadPoblacion = 130;
    mat_pool = new int[cantidadPoblacion * (cantidadPoblacion+1)/2];
    genes = new Vec3b * *[cantidadPoblacion + 10];
    n_genes = new Vec3b * *[cantidadPoblacion + 10];
    for(int i = 0; i < cantidadPoblacion+10; i++){
        genes[i] = new Vec3b *[filas];
        n_genes[i] = new Vec3b *[filas];
        for(int j = 0; j < filas; j++){
            genes[i][j] = new Vec3b [columnas];
            n_genes[i][j] = new Vec3b [columnas];
        }
    }
    poblacion = new algoritmoGenetico[cantidadPoblacion];
    for(int i = 0; i < cantidadPoblacion; i++){
        poblacion[i].inicializar(filas, columnas);
        poblacion[i].funcion_Fitness();
    }
    int generaciones = 0;
    while(true) {
        generaciones++;
        for (int i = 0; i < cantidadPoblacion; i++) {
            poblacion[i].funcion_Fitness();
        }
        sort(poblacion, poblacion + cantidadPoblacion, aptitud);
        cout << poblacion[0].fitness << endl;
        if (poblacion[0].fitness > 3000) {
            cout << generaciones << endl;
            break;
        }

        imshow("Soluciones", i.mostrar(obj->img, poblacion[0].colorPixel(best), obj->x, obj->y));
        waitKey(1);

        mat_len = 0;

        for(int i = 0; i < cantidadPoblacion; i++){
            for(int j = 0; j < cantidadPoblacion - i; j++){
                mat_pool[mat_len] = i;
                mat_len += 1;
            }
        }
        for(int i = 0; i < cantidadPoblacion; i++){
            int a = rand() % mat_len, b = rand() % mat_len;
            cruce(i, poblacion[mat_pool[a]], poblacion[mat_pool[b]]);
        }
        for(int i = 0; i < cantidadPoblacion; i++){
            poblacion[i].mutacion();
        }
        swap(genes, n_genes);
    }
    delete n_genes;
    delete genes;
}
