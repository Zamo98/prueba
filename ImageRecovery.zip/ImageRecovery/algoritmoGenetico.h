#ifndef IMAGERECOVERY_ALGORITMOGENETICO_H
#define IMAGERECOVERY_ALGORITMOGENETICO_H

#include "opencv2/opencv.hpp"
#include "cargarImagen.h"

using namespace cv;
using namespace std;

class algoritmoGenetico {
public:
    double fitness;
    int filas, columnas;
    int Indice;

    void inicializar(int filas, int columnas);
    void mutacion();
    void funcion_Fitness();
    Mat colorPixel(Mat image);
    void cruce(int pos, algoritmoGenetico padre, algoritmoGenetico madre);
    void principal();
};
bool aptitud(algoritmoGenetico a, algoritmoGenetico b);


#endif //IMAGERECOVERY_ALGORITMOGENETICO_H
