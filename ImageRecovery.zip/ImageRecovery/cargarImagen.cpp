#include "cargarImagen.h"
#include "opencv2/core.hpp"
#include <opencv2/core/utility.hpp>
#include "opencv2/imgproc/imgproc.hpp"
#include "opencv2/highgui/highgui.hpp"
#include "opencv2/imgcodecs.hpp"
#include "opencv2/opencv.hpp"

#include <stdio.h>
#include <stdlib.h>
#include <iostream>

using namespace std;
using namespace cv;

cargarImagen ::cargarImagen() {}

void cargarImagen::cargar() {

    for (int i = 0; i < image.rows; i++) {
        Vec3b *imgrow = image.ptr<Vec3b>(i);

        for (int j = 0; j < image.cols; j++) {

            uchar white = 255;

            imgrow[j][0] = white;
            imgrow[j][1] = white;
            imgrow[j][2] = white;

        }
    }
    imshow("Display Image", img);
    waitKey(0);
}

Mat cargarImagen::mostrar(Mat m1, Mat m2, int x, int y) {
    for(int i = x; i < m2.rows + x; i++){
        for(int j = y; j < m2.cols + y; j++){
            m1.at<Vec3b>(i,j) = m2.at<Vec3b>(i-x, j-y);
        }
    }
    return m1;
}

Mat cargarImagen::imagenFitness(Mat m, int _x, int _y, int _w, int _h) {
    imagenObjetivo;
    return m;
}