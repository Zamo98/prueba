#ifndef IMAGERECOVERY_CARGARIMAGEN_H
#define IMAGERECOVERY_CARGARIMAGEN_H

#include "opencv2/opencv.hpp"

using namespace cv;

class cargarImagen {
public:
    int x = 200;
    int y = 200;
    int w = 100;
    int h = 100;
    cargarImagen();
    void cargar();
    Mat mostrar(Mat m1, Mat m2, int _x, int _y);
    Mat imagenFitness(Mat m, int _x, int _y, int _w, int _h);
    Mat img = imread("/home/gustavo/ImageRecovery/Imagenes/patron.jpeg", IMREAD_COLOR);
    Mat image = img(Rect(x, y, w, h));
    Mat imagenObjetivo = img(Rect(x+100, y+100, w, h));

};

#endif //IMAGERECOVERY_CARGARIMAGEN_H
