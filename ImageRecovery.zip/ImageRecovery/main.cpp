#include "cargarImagen.h"
#include "algoritmoGenetico.h"
#include <iostream>

using namespace std;
cargarImagen *cargar = nullptr;
algoritmoGenetico *a = nullptr;

int main(){
    cargar = new cargarImagen();
    cargar->cargar();

    a = new algoritmoGenetico();
    a->principal();
    return 0;
}
